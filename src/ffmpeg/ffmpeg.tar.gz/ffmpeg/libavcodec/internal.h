#ifndef INTERNAL_H
#define INTERNAL_H

/**
 * @file internal.h
 * common functions for internal libavcodec use
 */


int av_tempfile(char *prefix, char **filename);

#endif /* INTERNAL_H */

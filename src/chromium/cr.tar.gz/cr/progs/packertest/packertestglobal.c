
/*
  Global vars
*/

int errChk;
int verbose;

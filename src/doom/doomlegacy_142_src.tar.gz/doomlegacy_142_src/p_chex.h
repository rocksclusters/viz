void Chex1PatchEngine(void);

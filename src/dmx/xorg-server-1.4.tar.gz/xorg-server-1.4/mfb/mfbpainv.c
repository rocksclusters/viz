#define OPEQ MFB_OPEQ_INVERT
#define MFBSOLIDFILLAREA mfbSolidInvertArea
#define EQWHOLEWORD MFB_EQWHOLEWORD_INVERT
#define MFBSTIPPLEFILLAREA mfbStippleInvertArea
#include "./mfbpntarea.c"

#define OP MFB_OP_BLACK
#define MFBTEGLYPHBLT mfbTEGlyphBltBlack
#define CLIPTETEXT mfbImageGlyphBltBlack
#include "./mfbtegblt.c"

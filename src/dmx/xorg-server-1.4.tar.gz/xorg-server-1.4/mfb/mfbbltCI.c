#define MROP McopyInverted
#include "./mfbblt.c"

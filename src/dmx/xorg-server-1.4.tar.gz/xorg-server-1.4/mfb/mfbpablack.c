#define OPEQ MFB_OPEQ_BLACK
#define MFBSOLIDFILLAREA mfbSolidBlackArea
#define EQWHOLEWORD MFB_EQWHOLEWORD_BLACK
#define MFBSTIPPLEFILLAREA mfbStippleBlackArea
#include "./mfbpntarea.c"

#define MROP Mcopy
#include "./mfbblt.c"

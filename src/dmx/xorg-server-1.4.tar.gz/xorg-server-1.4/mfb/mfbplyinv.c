#define OPEQ MFB_OPEQ_INVERT
#define MFBFILLPOLY1RECT mfbFillPolyInvert
#define EQWHOLEWORD MFB_EQWHOLEWORD_INVERT
#include "./mfbply1rct.c"

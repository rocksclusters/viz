#define MROP Mor
#include "./mfbblt.c"

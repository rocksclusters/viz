#define OP MFB_OP_WHITE
#define MFBTEGLYPHBLT mfbTEGlyphBltWhite
#define CLIPTETEXT mfbImageGlyphBltWhite
#include "./mfbtegblt.c"

#define MROP Mxor
#include "./mfbblt.c"

#define OPEQ MFB_OPEQ_WHITE
#define MFBSOLIDFILLAREA mfbSolidWhiteArea
#define EQWHOLEWORD MFB_EQWHOLEWORD_WHITE
#define MFBSTIPPLEFILLAREA mfbStippleWhiteArea
#include "./mfbpntarea.c"

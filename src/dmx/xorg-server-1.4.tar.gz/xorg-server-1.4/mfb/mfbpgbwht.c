#define OPEQ MFB_OPEQ_WHITE
#define MFBPOLYGLYPHBLT mfbPolyGlyphBltWhite
#include "./mfbplygblt.c"

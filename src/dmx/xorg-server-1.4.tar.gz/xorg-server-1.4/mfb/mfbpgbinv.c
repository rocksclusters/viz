#define OPEQ MFB_OPEQ_INVERT
#define MFBPOLYGLYPHBLT mfbPolyGlyphBltInvert
#include "./mfbplygblt.c"

#define OPEQ MFB_OPEQ_WHITE
#define MFBIMAGEGLYPHBLT mfbImageGlyphBltWhite
#include "./mfbimggblt.c"

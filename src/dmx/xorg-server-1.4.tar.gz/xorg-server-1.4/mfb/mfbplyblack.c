#define OPEQ MFB_OPEQ_BLACK
#define MFBFILLPOLY1RECT mfbFillPolyBlack
#define EQWHOLEWORD MFB_EQWHOLEWORD_BLACK
#include "./mfbply1rct.c"

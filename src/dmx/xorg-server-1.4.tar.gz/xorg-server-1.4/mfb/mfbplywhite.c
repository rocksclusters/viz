#define OPEQ MFB_OPEQ_WHITE
#define MFBFILLPOLY1RECT mfbFillPolyWhite
#define EQWHOLEWORD MFB_EQWHOLEWORD_WHITE
#include "./mfbply1rct.c"

#define OPEQ MFB_OPEQ_BLACK
#define MFBPOLYGLYPHBLT mfbPolyGlyphBltBlack
#include "./mfbplygblt.c"

#define OPEQ MFB_OPEQ_BLACK
#define MFBIMAGEGLYPHBLT mfbImageGlyphBltBlack
#include "./mfbimggblt.c"

#define RROP GXcopy
#include "../cfb/cfb8line.c"

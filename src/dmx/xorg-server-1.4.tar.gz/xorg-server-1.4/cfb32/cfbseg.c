#define POLYSEGMENT
#include "../cfb/cfbline.c"

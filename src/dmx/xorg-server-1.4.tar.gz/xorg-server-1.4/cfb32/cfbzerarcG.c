#define RROP GXset
#include "../cfb/cfbzerarc.c"

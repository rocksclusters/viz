#define MROP Mcopy
#include "../cfb/cfbtile32.c"

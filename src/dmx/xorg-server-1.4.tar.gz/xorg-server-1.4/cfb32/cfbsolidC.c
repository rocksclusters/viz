#define RROP GXcopy
#include "../cfb/cfbsolid.c"

#define RROP GXset
#define POLYSEGMENT
#include "../cfb/cfb8line.c"

#define RROP GXcopy
#include "../cfb/cfbfillarc.c"

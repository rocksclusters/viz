#define RROP GXset
#include "../cfb/cfb8line.c"

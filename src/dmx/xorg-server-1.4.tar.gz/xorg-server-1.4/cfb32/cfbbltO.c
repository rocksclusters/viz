#define MROP Mor
#include "../cfb/cfbblt.c"

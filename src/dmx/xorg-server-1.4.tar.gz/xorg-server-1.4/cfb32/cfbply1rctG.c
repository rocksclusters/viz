#define RROP GXset
#include "../cfb/cfbply1rct.c"

#define MROP Mxor
#include "../cfb/cfbblt.c"

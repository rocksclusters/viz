#ifdef HAVE_DIX_CONFIG_H
#include <dix-config.h>
#endif

#ifndef _CFBTAB_H_
#define _CFBTAB_H_

/* prototypes */
#if 0
extern int starttab[32], endtab[32];
extern unsigned int partmasks[32][32];
#endif

#endif /* _CFBTAB_H_ */

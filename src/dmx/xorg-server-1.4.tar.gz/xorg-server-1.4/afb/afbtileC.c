#define MROP Mcopy
#include "./afbtile.c"

#define MROP Mor
#include "./afbblt.c"

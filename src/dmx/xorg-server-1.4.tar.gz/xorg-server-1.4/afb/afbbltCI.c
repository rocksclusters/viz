#define MROP McopyInverted
#include "./afbblt.c"

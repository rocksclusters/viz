#include "../../mi/miinitext.c"

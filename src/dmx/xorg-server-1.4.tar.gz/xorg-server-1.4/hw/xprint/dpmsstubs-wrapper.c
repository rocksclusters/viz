#include "../../Xext/dpmsstubs.c"
